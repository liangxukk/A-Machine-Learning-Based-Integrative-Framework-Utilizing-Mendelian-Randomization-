# 09. ceRNA ----------------------------------------------------------------

file_name <- "08_ceRNA"
dir.create(file_name)
setwd(file_name)

m_2_mi <- fread("D:/00_Laborer/00_1741/01_Database/StarBase/human/ENCORI_hg38_mRNA.txt")
mi_2_lnc <- fread("D:/00_Laborer/00_1741/01_Database/StarBase/human/ENCORI_hg38_lncRNA.txt")
coxGene <- c("BNC2", "MRAP2", "PLEKHA2")
res_miRNA <- m_2_mi %>% subset(geneName %in% coxGene
                               & TDMDScore >= 1
                               & clipExpNum >= 1
                               # &  miRanda >= 1
                               # &  PITA >= 1
                               &  microT >= 1
                               # &  PicTar >= 1
                               &  miRmap >= 1
)
table(res_miRNA$geneName)
write.csv(res_miRNA, "01_res_mRNA.csv", row.names = F)
hub_mi <- res_miRNA$miRNAname %>% unique()
table(res_miRNA$miRNAname) %>% length() ## 42

res_lnc <- mi_2_lnc %>% subset(miRNAname %in% hub_mi
                               & TDMDScore >= 1
                               & clipExpNum >= 20
)
table(res_lnc$geneName) %>% length() # 38
table(res_lnc$miRNAid) %>% length() # 37
write.csv(res_lnc, "02_res_lnc.csv", row.names = F)

dt_mi <- data.frame(node1 = res_miRNA$miRNAname, node2 = res_miRNA$geneName)
dt_lnc <- data.frame(node1 = res_lnc$miRNAname, node2 = res_lnc$geneName)
network <- rbind(dt_mi, dt_lnc) %>% unique()
write.table(network, "03_ceRNA.txt", row.names = F,sep = "\t", quote = F)
all <- c(res_miRNA$geneName, res_miRNA$miRNAname, res_lnc$geneName) %>% unique()
label <- ifelse(all %in% coxGene, "mRNA", ifelse(all %in% hub_mi, "miRNA", "lncRNA"))
node <- data.frame(node = all, label = label)
write.csv(node, "04_node.csv", row.names = F)
cat(paste0("miRNA: ", table(res_miRNA$miRNAname) %>% length(), "  lncRNA: ", table(res_lnc$geneName) %>% length()),
    file = paste0("05_Number.log"), append = T, sep = '\n')



mycol <- c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462',
           '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8',
           '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', '#F781BF', '#66C2A5', 
           '#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b', '#049a0b', '#BEAED4', 
           '#FDC086', '#FFFF99', '#386CB0', '#F0027F', '#4253ff', '#ff4308', '#D8D155',
           '#64495D', '#7CC767','#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462',
           '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8',
           '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', '#F781BF', '#66C2A5', 
           '#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b', '#049a0b', '#BEAED4', 
           '#FDC086', '#FFFF99', '#386CB0', '#F0027F', '#4253ff', '#ff4308', '#D8D155',
           '#64495D', '#7CC767','#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462',
           '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8',
           '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', '#F781BF', '#66C2A5', 
           '#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b','#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462',
           '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8',
           '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', '#F781BF', '#66C2A5', 
           '#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b', '#049a0b', '#BEAED4', 
           '#FDC086', '#FFFF99', '#386CB0', '#F0027F', '#4253ff', '#ff4308', '#D8D155',
           '#64495D', '#7CC767','#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462',
           '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8',
           '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', '#F781BF', '#66C2A5', 
           '#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b', '#049a0b', '#BEAED4', 
           '#FDC086', '#FFFF99', '#386CB0', '#F0027F', '#4253ff', '#ff4308', '#D8D155',
           '#64495D', '#7CC767','#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462',
           '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8',
           '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', '#F781BF', '#66C2A5', 
           '#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b','#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462',
           '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8',
           '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', '#F781BF', '#66C2A5', 
           '#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b', '#049a0b', '#BEAED4', 
           '#FDC086', '#FFFF99', '#386CB0', '#F0027F', '#4253ff', '#ff4308', '#D8D155',
           '#64495D', '#7CC767','#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462',
           '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8',
           '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', '#F781BF', '#66C2A5', 
           '#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b', '#049a0b', '#BEAED4', 
           '#FDC086', '#FFFF99', '#386CB0', '#F0027F', '#4253ff', '#ff4308', '#D8D155',
           '#64495D', '#7CC767','#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462',
           '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8',
           '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', '#F781BF', '#66C2A5', 
           '#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b')


library(ggalluvial)
library(RColorBrewer)
mypalette <- colorRampPalette(brewer.pal(8,"Set3"))
# setwd("D:/work/2023/2023.09/R2_NN-0129-3/02_result/11_ceRNA_Sans/")
mRNA <- res_miRNA[,c(2,4)]
lncRNA <- res_lnc[,c(2,4)]
lnc_ce <- merge(mRNA,lncRNA,by="miRNAname")
colnames(lnc_ce) <- c("miRNA","mRNA","lncRNA")
length(table(lnc_ce$miRNA));length(table(lnc_ce$mRNA));length(table(lnc_ce$lncRNA))
write.csv(lnc_ce,"04_lncRNA_miRNA_mRNA.csv",row.names = F)
# pdf(file="lncRNA_miRNA_mRNA_san.pdf",width=8,height=6,onefile=F)
# ggplot(lnc_ce, aes(axis1 = lncRNA, axis2 = miRNA, axis3 = mRNA)) +
#   geom_alluvium(aes(fill = mRNA), width = 0.5) +
#   geom_stratum(width = 3/8) +
#   guides(fill = "none") +
#   # geom_label(stat = "stratum",aes(label = after_stat(stratum)))+
#   # scale_fill_brewer(type = "qual",palette = "Set3")+
#   scale_fill_brewer(type = "qual",palette = "Set2")+
#   geom_text(stat = "stratum", aes(label = after_stat(stratum)), size = 3) +
#   # coord_flip() +
#   theme_void()
# dev.off()



lnc_ce$link <- 1
lnc_ce <- reshape::melt(lnc_ce, id = 'link')
variable <- summary(lnc_ce$variable)
# write.csv(lnc_ce,"new_Network.csv")

lnc_ce$flow <- rep(1:variable[1], length(variable))
# head(lnc_ce)

pdf("05_Network.pdf",width =22,height =  25)
ggplot(lnc_ce,aes(x =variable,y =link, stratum = value, alluvium = flow , fill =value)) +geom_stratum()+
  scale_fill_manual(values = mycol) +  
  geom_flow(aes.flow =  "forward")+
  geom_text(aes(label = value) ,stat = 'stratum', size = 6) +
  scale_x_discrete(limit = c('mRNA', 'miRNA', 'lncRNA'))+
  labs(x = '', y = '',size = 15) +  
  theme(legend.position = 'none', 
        panel.background = element_blank(),
        line = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_text(size = 45)
        )  #去除背景和图例
dev.off()

setwd("..")
