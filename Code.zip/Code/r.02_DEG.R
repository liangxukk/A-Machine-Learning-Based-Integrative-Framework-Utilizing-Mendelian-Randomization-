
## Data
pacman::p_load(GEOquery, affy, oligo, magrittr, dplyr, tidyr, data.table, stringr, readxl, tibble) 

## DEGs
pacman::p_load(limma, DEqMS, DESeq2, edgeR, ggplot2, ggrepel, pheatmap, circlize, ComplexHeatmap, heatmap3) 
# 0. data -----------------------------------------------------------------

if(! dir.exists("00_cleandata")){
  dir.create("00_cleandata")
}

## 0.1 Train-TCGA----------------------------------------------------------

GSE_accession = "TCGA-PRAD"
exp_xl_count <- fread("00_Rawdata/TCGA-PRAD/TCGA-PRAD.star_counts.tsv.gz")
exp_xl_fpkm <- fread("00_Rawdata/TCGA-PRAD/TCGA-PRAD.star_fpkm.tsv.gz")
ann_xl <- fread("00_Rawdata/TCGA-PRAD/gencode.v36.annotation.gtf.gene.probemap")[,1:2]
phe_xl <- fread("00_Rawdata/TCGA-PRAD/TCGA-PRAD.clinical.tsv.gz")
sur_xl <- fread("00_Rawdata/TCGA-PRAD/TCGA-PRAD.survival.tsv.gz")
mRNA <- readLines("D:/00_Laborer/00_1741/01_Database/GDC-TCGA/mRNA.txt")

## count
exp_xl_count <- merge(ann_xl, exp_xl_count, by.x = "id", by.y = "Ensembl_ID")
exp_xl_count <- aggregate(. ~ gene, data = exp_xl_count[,-1], max)
rownames(exp_xl_count) <- exp_xl_count[,1]
exp_xl_count <- exp_xl_count[,-1]

## fpkm
exp_xl_fpkm <- merge(ann_xl, exp_xl_fpkm, by.x = "id", by.y = "Ensembl_ID")
exp_xl_fpkm <- aggregate(. ~ gene, data = exp_xl_fpkm[,-1], max)
rownames(exp_xl_fpkm) <- exp_xl_fpkm[,1]
exp_xl_fpkm <- exp_xl_fpkm[,-1]

## sample
# sample_xl <- Reduce(intersect, list(sur_xl$sample, colnames(exp_xl_count)))
group_xl <- data.frame(sample = colnames(exp_xl_count), group = substr(colnames(exp_xl_count), 14, 16))
table(group_xl$group)
# 01A 01B 06A 11A 11B 
# 483  18   1  51   1 
group_xl <- group_xl[group_xl$group == "01A" | group_xl$group == "11A",]
group_xl$group <- ifelse(group_xl$group == "01A", "Case", "Control")
group_xl$group <- factor(group_xl$group, levels = c("Control", "Case"))
group_xl <- group_xl[order(group_xl$group),]
rownames(group_xl) <- group_xl$sample
# sample_01A <- group_xl$sample[group_xl$group == "01A"]
# sample_06A <- group_xl$sample[group_xl$group == "06A"]
write.csv(group_xl, file = paste0("00_cleandata/group_", GSE_accession, ".csv"))
group_xl <- read.csv("00_cleandata/group_TCGA-PRAD.csv", row.names = 1)

## expression

exp_xl_count <- exp_xl_count[,group_xl$sample]
exp_xl_count <- 2^exp_xl_count-1
exp_xl_count <- round(exp_xl_count, digits = 0)
exp_xl_count <- exp_xl_count[rowSums(cpm(exp_xl_count) > 0.5 ) >= ncol(exp_xl_count)*0.5,]
exp_xl_count <- exp_xl_count[rownames(exp_xl_count) %in% mRNA,]
exp_xl_fpkm <- exp_xl_fpkm[rownames(exp_xl_count),group_xl$sample]
# exp_xl_fpkm <- exp_xl_fpkm[,group_xl$sample]
write.csv(exp_xl_count, file = paste0("00_cleandata/expression_count_", GSE_accession, ".csv"))
write.csv(exp_xl_fpkm, file = paste0("00_cleandata/expression_fpkm_", GSE_accession, ".csv"))
exp_xl_fpkm <- read.csv("00_cleandata/expression_fpkm_TCGA-PRAD.csv", row.names = 1, check.names = F)

## 0.2 Test-GSE21034----------------------------------------------------------

list.files("00_Rawdata/")
GSE_accession <- "GSE21034"
GSE_destdir <- paste0("00_Rawdata/", GSE_accession, "/")
# GSExx <- getGEO(GSE_accession, destdir = GSE_destdir, getGPL = F)
GSExx <- getGEO(filename = "00_Rawdata/GSE21034/GSE21034-GPL10264_series_matrix.txt.gz", destdir = GSE_destdir, getGPL = F)
exp <- exprs(GSExx) %>% as.data.frame() 
phe  <- pData(GSExx) %>% as.data.frame()
list.files(paste0("00_Rawdata/", GSE_accession))
# GPL_accession <- "GPL570"
# GPLxx <- getGEO(filename = paste0("00_Rawdata/",GSE_accession, "/", GPL_accession,".annot.gz"), AnnotGPL = T) # 平台注释文件
# gpl <- Table(GPLxx)
gpl <- fread("00_Rawdata/GSE21034/GPL10264.txt")


## Group
head(phe)
phe[is.na(phe)] <- ""
phe <- phe[phe$`tumor type:ch1` != "Metastasis",]
table(phe$`disease status:ch1`)

group <- phe %>% dplyr::select(sample = geo_accession,
                               group = `disease status:ch1`)
table(group$group)
# group$group <- substr(group$group,1,6)
group <- group %>% mutate(group = case_when(group == "normal adjacent benign prostate" ~ "Control",
                                            group == "prostate cancer" ~ "Case",
                                            TRUE ~ NA_character_)) %>% na.omit()
table(group$group)
group$group <- factor(group$group, levels = c("Control", "Case"))
group <- group[order(group$group), ]
rownames(group) <- group$sample
group_yz = group
write.csv(group, file = paste0("00_cleandata/group_", GSE_accession, ".csv"), row.names = F)

# Annotion & Expression
ensembl <- useMart("ensembl", dataset = "hsapiens_gene_ensembl")
# ensembl <- useEnsembl(biomart = "ensembl", dataset = "hsapiens_gene_ensembl", mirror = "useast")
results <- getBM(attributes = c("refseq_mrna", "hgnc_symbol"),
                 filters = "refseq_mrna",
                 values = gpl$GB_ACC,
                 mart = ensembl)

ENTREZID <- bitr(gpl$GB_ACC, fromType = "REFSEQ", toType=c("SYMBOL"), OrgDb = org.Hs.eg.db)
gpl <- merge(gpl, ENTREZID, by.x = "GB_ACC", by.y = "REFSEQ")
gpl <- gpl[,-1]
colnames(gpl)
ann <- gpl %>% dplyr::select(ID,
                      symbol = SYMBOL)
exp <- exp %>% dplyr::select(group$sample)
exp <- data.frame(ID = rownames(exp), exp)
ann$ID <- as.character(ann$ID)
exp <- merge(ann, exp, by = "ID")
exp <- exp %>% subset(symbol != "" | symbol != "---")
exp <- exp[, -1] %>% as_tibble() %>% separate_rows(symbol, sep = "///")
exp <- aggregate(. ~ symbol, data = exp, max)
rownames(exp) <- exp[,1]
exp <- exp[, -1] 
range(exp)
exp <- log2(exp)
exp_yz <- exp
write.csv(exp, file = paste0("00_cleandata/expression_", GSE_accession, ".csv"))

# 1. DEG -------------------------------------------------------------------

if(! dir.exists("02_DEG")){
  dir.create("02_DEG")
}

exp_xl_count <- read.csv("00_cleandata/expression_count_TCGA-PRAD.csv", row.names = 1, check.names = F)
exp_xl_fpkm <- read.csv("00_cleandata/expression_fpkm_TCGA-PRAD.csv", row.names = 1, check.names = F)
group_xl <- read.csv("00_cleandata/group_TCGA-PRAD.csv", row.names = 1)
group_xl$group <- factor(group_xl$group, levels = c("Control", "Case"))
dataExpr <- exp_xl_count
group <- group_xl
coldata <- data.frame(condition = group$group)
coldata$condition <- factor(coldata$condition, levels = c("Control", "Case"))
table(coldata) 
# condition
# Control    Case 
# 51     483 

logFoldChange <- 0.5
adj.P.Val <- 0.05
p_choose <- "padj"  # pvalue  padj

dds <- DESeqDataSetFromMatrix(countData = dataExpr, 
                              colData = coldata, 
                              design = ~ condition)
dds1 <- DESeq(dds)
exp_xl_norm <- as.data.frame(counts(dds1, normalized=TRUE))
write.csv(exp_xl_norm, "02_DEG/00_expression_normalized.csv")
res <- results(dds1, contrast = c('condition', "Case", 'Control'))
write.table(data.frame(symbol = rownames(res), res), 
            file = "02_DEG/02_DEG_all_information.csv", sep = ",", row.names = F)

res <- res %>% as.data.frame() %>% na.omit()
# res <- res[,-6] %>% na.omit()
diffSig_DEG <- res[(res[,p_choose] < adj.P.Val & abs(res$log2FoldChange) >= logFoldChange), ] %>% as.data.frame()
DEG <- rownames(diffSig_DEG)
DEG_up <- rownames(diffSig_DEG)[diffSig_DEG$log2FoldChange > 0]
DEG_dw <- rownames(diffSig_DEG)[diffSig_DEG$log2FoldChange < 0]
write.table(DEG, file = "02_DEG/03_DEGs.txt", row.names = F, col.names = F, quote=F)
write.table(DEG_up, file = "02_DEG/03_DEGs_up.txt", row.names = F, col.names = F, quote=F)
write.table(DEG_dw, file = "02_DEG/03_DEGs_dw.txt", row.names = F, col.names = F, quote=F)
write.table(data.frame(symbol = rownames(diffSig_DEG), diffSig_DEG), 
            file = "02_DEG/02_DEG_sig_information.csv", sep = ",", row.names = F)
cat(paste0('TCGA( ', p_choose, '< 0.05, log|FC| >= ',logFoldChange,'): DEGs: ', length(DEG), "; DEGs_up: ", length(DEG_up), "; DEGs_down: ", length(DEG_dw)),
    file = paste0("02_DEG/00_TCGA_DEGs.log"), append = T, sep = '\n')

# 火山图

DEGs_file <- res %>% as.data.frame() 
DEGs_file$color <- ifelse(DEGs_file[,p_choose] < adj.P.Val & abs(DEGs_file$log2FoldChange) >= logFoldChange,
                          ifelse(DEGs_file$log2FoldChange > logFoldChange, "Up expression", "Down expression"), 
                          "Non significant")
DEGs_file$color <- factor(DEGs_file$color, levels = c("Up expression", "Down expression", "Non significant"))
colnames(DEGs_file)[colnames(DEGs_file) == p_choose] <- "p_choose"
table(DEGs_file$color)
label <- c(rownames(DEGs_file %>% slice_max(log2FoldChange, n = 5)), rownames(DEGs_file %>% slice_min(log2FoldChange, n = 5)))
color <- c("Up expression" = "#E63863", "Non significant" = "gray", "Down expression" = "#68A180")
shape <- c("Up expression" = 24, "Non significant" = 16, "Down expression" = 25)
p <- ggplot(DEGs_file, aes(log2FoldChange, -log10(p_choose), col = color)) +
  geom_point(aes(shape = color, fill = color), size=2) +
  theme_bw() +
  scale_color_manual(values = color) +
  scale_shape_manual(values = shape) +
  labs(x = paste0("log2(Fold-change Case VS Control)"), y = paste0("-log10(", p_choose, ")")) +
  geom_label_repel(
    data = DEGs_file[label,],
    aes(label = label),
    size = 5,
    # fill = "darkred", color = "white",
    box.padding = unit(0.35, "lines"),
    point.padding = unit(0.3, "lines"),
    show.legend = F
  ) +
  geom_hline(yintercept = -log10(adj.P.Val), lty = 4, col = "#E39A35", lwd = 1) + 
  geom_vline(xintercept = c(-logFoldChange, logFoldChange), lty = 4, col = "#E39A35", lwd = 1) +
  # annotate("text", x = 2, y = 0, label = "|logFC|>1", size = 5, col = "black") +
  # annotate("text", x = 4, y = 2, label = "adj.p<0.05", size = 5, col = "black") +
  theme(
    # plot.margin = unit(rep(3, 4), "lines"), 
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    text = element_text(size = 12),
    axis.title.x = element_text(face = "bold", size = 16),
    axis.title.y = element_text(face = "bold", size = 16),
    axis.text.x = element_text(size = 14, angle = 0),
    axis.text.y = element_text(size = 14, angle = 0),
    legend.text = element_text(face = "bold", size = 13),
    legend.title = element_blank(),
    panel.grid = element_blank(),
    axis.line = element_line(linewidth = 1, colour = "black"),
    panel.border = element_blank(),
    legend.position = "bottom"
  )

pdf(file = paste0("02_DEG/04_DEGs_volcano.pdf"), height = 8, width = 8, onefile = FALSE)
print(p)
dev.off()

## heatmap

top_10_up <- DEGs_file %>% slice_max(n = 10, order_by = log2FoldChange)
top_10_down <- DEGs_file %>% slice_min(n = 10, order_by = log2FoldChange)
top_20 <- rbind(top_10_up, top_10_down)
top_20 <- rownames(top_20)

n_con <- table(coldata)[[1]]
n_case <- table(coldata)[[2]]

# red_de_expr <- log2(exp_xl_count[DEG, ] + 1)
# red_de_expr <- exp_xl_fpkm[DEG, ]
red_de_expr <- log2(exp_xl_count[top_20, ] + 1)
ha1 = HeatmapAnnotation(Sample = c(rep("Control", n_con), rep("Case", n_case)),
                        col = list(Sample = c("Control" = "#68A180", "Case" = "#E63863")))
ha2 = rowAnnotation(Gene = c(rep("Up", 10), rep("Down", 10)),
                    col = list(Gene = c("Up" = "#E95C59", "Down" = "#295599")))
# draw(ha1)
madt <- as.matrix(red_de_expr)
madt2 <- t(scale(t(madt)))

range(madt2)
# cap <- function(x){
#   x <- as.matrix(x)
#   a <- quantile(x, probs = c(0.1, 0.9))
#   x = ifelse(x < a[1], a[1], x)
#   x = ifelse(x > a[2], a[2], x)
# }
# madt2 <- apply(madt2, 1, cap) %>% t()
# colnames(madt2) <- colnames(red_de_expr)
# madt2 <- apply(madt2, 2, cap) %>% as.data.frame()
# rownames(madt2) <- top_20
# madt2 <- madt2 %>% as.matrix()

p <- 
  densityHeatmap(madt2,
                 # ylim = c(-2, 2),
                 title = "Distribution as heatmap", 
                 ylab = "Expression",
                 # col = topo.colors(10)
                 col = c('#295599', '#3e94c0', '#78c6d0', '#b4d9e4', '#fffef0', '#f9cdac', '#ec7d92', '#bc448c')
  ) %v%
  Heatmap(madt2, 
          col = colorRampPalette(c("#295599", "white","#E64B357F"))(50),
          top_annotation = ha1,
          left_annotation = ha2,
          show_row_names = T ,
          show_column_names = F ,
          name = "Expr", 
          use_raster = T,
          # cluster_rows = F,
          height = unit(16, "cm"))

pdf(file=paste0("02_DEG/DEGs_pheatmap.pdf"),width=10,height=9,onefile=FALSE)
print(p)
dev.off()

# heatmap2
# library('ComplexHeatmap')
# library('circlize')
# library(plyr)

top_10_up <- DEGs_file %>% slice_max(n = 20, order_by = log2FoldChange)
top_10_down <- DEGs_file %>% slice_min(n = 20, order_by = log2FoldChange)
top_20 <- rbind(top_10_up, top_10_down)
top_20 <- rownames(top_20)

de_expr <- log2(exp_xl_count[top_20, ] + 1)
# de_expr <- exp_xl_fpkm[top_20, ]
madt<-as.matrix(de_expr)
madt2<-t(scale(t(madt)))
range(madt2)
# cap <- function(x){
#   x <- as.matrix(x)
#   a <- quantile(x, probs = c(0.1, 0.9))
#   x = ifelse(x < a[1], a[1], x)
#   x = ifelse(x > a[2], a[2], x)
# }
# madt2 <- apply(madt2, 1, cap) %>% t()
# colnames(madt2) <- colnames(dataExpr)
# madt2 <- apply(madt2, 2, cap) %>% as.data.frame()
# rownames(madt2) <- top_20

#重新定义热图颜色梯度：
mycol=colorRamp2(c(min(madt2), 0, max(madt2)),c("#295599", "white","#E64B357F"))

#绘制基础环形热图：

n_con <- table(coldata)[[1]]
n_case <- table(coldata)[[2]]

pdf(file="02_DEG/05_DEGs_circpheatmap.pdf",width=8,height=8,onefile=FALSE)
# circos.heatmap(madt2,col=mycol)
# circos.clear()#绘制完成后需要使用此函数完全清除布局
#加基因名
circos.par(gap.after=c(50))
circos.heatmap(madt2,col=mycol,dend.side="inside",rownames.side="outside",
               rownames.col="black",
               rownames.cex=0.9,
               rownames.font=1,
               track.height = 0.4,
               cluster=F)
#circos.clear()

circos.track(track.index = get.current.track.index(), panel.fun = function(x, y) {
  if(CELL_META$sector.numeric.index == 1) { # the last sector
    circos.rect(CELL_META$cell.xlim[2.5] + convert_x(1, "mm"), 0,
                CELL_META$cell.xlim[2.5] + convert_x(7, "mm"),n_case,
                col = "#FF7F00", border = NA)
    circos.text(CELL_META$cell.xlim[2.5] + convert_x(4, "mm"), n_case/2,
                "Case", cex = 0.9, facing = "clockwise")
    
    circos.rect(CELL_META$cell.xlim[2.5] + convert_x(1, "mm"), n_case,
                CELL_META$cell.xlim[2.5] + convert_x(7, "mm"), nrow(coldata),
                col = "#91D1C2FF", border = NA)
    circos.text(CELL_META$cell.xlim[2.5] + convert_x(4, "mm"), (n_case + n_con/2),
                "Control ", cex = 0.9, facing = "clockwise")
  }
}, bg.border = NA) #这个是样本多的时候 大概的加一个分组的label  


lg=Legend(title="Exp",col_fun=mycol,direction = c("vertical"))
grid.draw(lg)
circos.clear()
dev.off()

