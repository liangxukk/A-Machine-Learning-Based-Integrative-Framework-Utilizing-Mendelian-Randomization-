## Plot
pacman::p_load(ggplot2, ggpubr, aplot, ggvenn, psych, ggcorrplot, corrplot, pROC, UpSetR, patchwork, VennDiagram, eulerr, ggcor, ggunchained, ggrepel) 
## Machine learning
pacman::p_load(glmnet, e1071, caret, doParallel, parallel, kableExtra, Boruta, neuralnet, NeuralNetTools, caret) 


# 4. Machine learning ------------------------------------------------------------------

file_name <- "04_Machine_Learning"; dir.create(file_name); setwd(file_name)

## 5.1 LASSO --------------------------------------------------------------------------------------------------------

Machine_exp <- exp_xl_fpkm
Machine_group <- group_xl
Machine_gene <- gene_enrich

data_mac <- data.frame(Machine_group, t(Machine_exp[Machine_gene,]), check.names = F)[,-1]
# data_mac$group <- ifelse(data_mac$group == "Control",0,1) %>% factor(.,levels = c(0,1),ordered = F)
data_mac$group <- ifelse(data_mac$group == "Control",0,1)
lasso.v <- as.matrix(data_mac)
# lasso.v <- as.data.frame(data_mac)
write.csv(lasso.v, file = "00_Machine_Learning_data.csv")

# Lasso regression
set.seed(2)
fit_stage.v <- cv.glmnet(lasso.v[, -1], lasso.v[, "group"],
                         family = "binomial", type.measure = "default", nfolds = 5, gamma = 1)
fit_stage.v
fit.v <- fit_stage.v$glmnet.fit
coef <- coef(fit_stage.v, s = fit_stage.v$lambda.min)
pdf(file = "01_lasso.Binomial.Deviance.pdf", height = 6, width = 6)
par(mgp = c(2.5, 1, 0), mar = c(4, 5, 3, 1))
plot(fit_stage.v, xlab = "Log Lambda", cex.lab = 1.5) +
  text(
    x = log(fit_stage.v$lambda.min), y = 0.5,
    paste("Lambda.min\n", round(fit_stage.v$lambda.min, 4)), cex = 1.3, adj = 0.5
  ) 
  # text(
  #   x = log(fit_stage.v$lambda.1se), y = 1.2,
  #   paste("Lambda.lse\n", round(fit_stage.v$lambda.1se, 4)), cex = 1.3, adj = 0.5
  # )
  dev.off()

pdf(file = "02_lasso.voefficients.venalty.pdf", height = 6, width = 6)
par(mgp = c(2.5, 1, 0), mar = c(4, 5, 3, 1))
plot(fit.v, xvar = "lambda", cex.lab = 1.5) +
  abline(v = c(log(fit_stage.v$lambda.min), log(fit_stage.v$lambda.1se)), lty = 2) +
  text(
    x = log(fit_stage.v$lambda.min), y = 0.5,
    paste("Lambda.min\n", round(fit_stage.v$lambda.min, 4)), cex = 1.3, adj = 0.5
  ) 
  # text(
  #   x = log(fit_stage.v$lambda.1se), y = 10,
  #   paste("Lambda.lse\n", round(fit_stage.v$lambda.1se, 3)), cex = 1.3, adj = 0.5
  # )
  dev.off()

## Table. LASSO(Training set)
lam <- fit_stage.v$lambda.min
pre_train <- predict(fit_stage.v, type = "class", newx = lasso.v[, -1], s = lam)
acc_table_tr <- table(pre_train, lasso.v[, "group"])
colnames(acc_table_tr) <- c("Control", "Case")
rownames(acc_table_tr) <- c("Control", "Case")
kable(acc_table_tr, "html", caption = "<center>**Table LASSO(Training set) **</center>") %>%
  kable_styling(bootstrap_options = "striped", full_width = F)

# Feature gene
coefficients <- coef(fit_stage.v, s = lam)
Active.Index <- coefficients@i
Active.coefficients <- coefficients@x
Active.name.train <- colnames(lasso.v[, -1])[Active.Index[-1]]
lasso_res <- data.frame(gene = c("Intercept", Active.name.train), coefficients = Active.coefficients)
Active.name.train
write.csv(lasso_res, file = "03_lasso_result.csv", row.names = F)
write.table(Active.name.train, file = "04_lasso_gene.txt",row.names = F, col.names = F, quote=F)


## 5.2 SVM-RFE ----------------------------------------------------------------------------------------------------------

source("D:/00_Laborer/00_1741/01_Database/00_code/Machine_learning/msvmRFE.r")
set.seed(22)  # 222
data.c <- data_mac
svmRFE(data.c, k = 10, halve.above = 100)
nfold <- 10
nrows <- nrow(data.c)
folds <- rep(1:nfold, len = nrows)[sample(nrows)]
folds <- lapply(1:nfold, function(x) which(folds == x))
results <- lapply(folds, svmRFE.wrap, data.c, k = 10, halve.above = 100)
top.features <- WriteFeatures(results, data.c, save = F)
kable(top.features[1:10, ], "html", caption = "<center>**Table SVM-RFE(Training set) **</center>") %>%
  kable_styling(bootstrap_options = "striped", full_width = F)

cl <- makeCluster(13)
registerDoParallel(cl) 
mydata1c <- foreach(
  i = 1:(ncol(data.c)-1), 
  .combine = rbind,
  .packages = c("e1071")
) %dopar% FeatSweep.wrap(i, results, data.c)
stopCluster(cl)
no.info <- min(prop.table(table(data.c[, 1])))
errors <- as.data.frame(mydata1c)
errors <- errors$error
pdf(file = "05_svm.error.pdf", height = 4, width = 5)
par(mgp = c(2.5, 1, 0), mar = c(4, 4, 1, 1))
PlotErrors(unlist(errors), no.info = 0.4444)
dev.off()

## Get genes

fea_gene <- top.features[1:which.min(errors)[[1]], 1]
cancerdata <- data.c
cancerdata$group <- as.factor(data.c$group)
cancerdata <- cancerdata[, c(1, which(colnames(cancerdata) %in% fea_gene))]

can_svm <- svm(group ~ ., data = cancerdata, kernel = "linear")
# summary(can_svm)
train_pre <- as.character(predict(can_svm, cancerdata))
sprintf("base SVM acc: %f", recall(cancerdata$group, as.factor(train_pre)))
acc <- table(cancerdata$group, train_pre)
colnames(acc) <- c("Control", "Case")
rownames(acc) <- c("Control", "Case")
kable(acc, "html", caption = "<center>**Table SVM(Training set) **</center>") %>%
  kable_styling(bootstrap_options = "striped", full_width = F)
write.table(fea_gene, file = "06_svm_gene.txt",row.names = F, col.names = F, quote=F)

## 5.3 Boruta-------------------------

set.seed(666) # 888
bor <- Boruta(data_mac[,-1],data_mac$group, doTrace = 3)
print(bor)

pdf(file = "07_Boruta.pdf",height = 6,width = 8)
par(mgp = c(2, 1, 0), mar = c(7, 3, 1, 1))
plot(bor, las = 2, cex.axis = 1, xlab = "")
dev.off()
pdf(file = "07_Boruta_line.pdf",height = 6,width = 8)
par(mgp = c(2, 1, 0), mar = c(3, 3, 1, 1))
plotImpHistory(bor, cex.axis = 1)
dev.off()

sel <- getSelectedAttributes(bor)

print(sel)
write.table(sel, file = "08_Boruta_gene.txt",row.names = F, col.names = F, quote=F)

## 5.4 key gene--------------------------------

hub <- Reduce(intersect, list(Active.name.train, fea_gene))
write.table(hub, file = "09_hub_gene.txt", row.names = F, col.names = F, quote=F)

upset_list <- list(LASSO = Active.name.train,
                   `SVM-RFE` = fea_gene,
                   Boruta = sel
)
pdf(file = "10_Machine_learning_venn.pdf",height=5,width=5,onefile=FALSE)
ggvenn(upset_list, 
       stroke_linetype = 2, 
       stroke_size = 1,
       text_size = 4,
       text_color = "black",
       # set_name_color = "red", 
       set_name_size = 4,
       fill_color = c("#91D0BE", "gold","pink"))
dev.off()

## 5.5 ROC ---------------------------------------------------------------------------------------------------------

GSE_accession = "TCGA-PRAD"
exp_xl_count <- read.csv("00_cleandata/expression_count_TCGA-PRAD.csv", row.names = 1, check.names = F)
exp_xl_fpkm <- read.csv("00_cleandata/expression_fpkm_TCGA-PRAD.csv", row.names = 1, check.names = F)
group_xl <- read.csv("00_cleandata/group_TCGA-PRAD.csv", row.names = 1)
group_xl$group <- factor(group_xl$group, levels = c("Control", "Case"))
exp_roc <- exp_xl_fpkm
group_roc <- group_xl

GSE_accession <- "GSE21034"
exp_yz <- read.csv("../00_cleandata/expression_GSE21034.csv", row.names = 1, check.names = F)
group_yz <- read.csv("../00_cleandata/group_GSE21034.csv")
rownames(group_yz) <- group_yz$sample
group_yz$group <- factor(group_yz$group, levels = c("Control", "Case"))
exp_roc <- exp_yz
group_roc <- group_yz

hub <- c("BNC2", "MRAP2", "PLEKHA2")

roc_data <- data.frame(group = group_roc$group, t(exp_roc[hub,] %>% na.omit()), check.names = F)
# roc_data <- data.frame(group = group_roc$group, t(log2(exp_roc[hub,] + 1) %>% na.omit()), check.names = F)
write.csv(roc_data, file = paste0("11_roc_data_", GSE_accession, ".csv"), row.names = F)

## expression

box <- roc_data %>% gather(gene, exp, -group)
box$gene <- factor(box$gene, levels = hub)

Controlnumber <- table(roc_data$group)[1]
d <- c()
e <- c()
for(i in colnames(roc_data)[-1]){
  a = median(roc_data[c(1:Controlnumber),i])
  b = median(roc_data[-c(1:Controlnumber),i])
  pa <- wilcox.test(roc_data[c(1:Controlnumber),i],roc_data[-c(1:Controlnumber),i])
  p = pa$p.value
  c = if_else(p>0.05,"black",if_else(a>b,"#68A180","#8C549C"))
  d <- c(d,c)
  e <- c(e,c,c)
}

pdf(file = paste0("12_hub_box_", GSE_accession, ".pdf"), height = 5,width = 8)
ggplot(box,aes(x = gene,y = exp, fill = group)) + 
  geom_boxplot(alpha=0.7, col = e) + 
  scale_fill_manual(values=c("#53A85F","#E95C59"))+ 
  ylim(min(box$exp), (max(box$exp)*1.1))+
  #scale_x_discrete()+
  labs(x="",y="Expression level", title = GSE_accession)+
  theme_bw() + 
  theme(#plot.margin=unit(rep(3,4),'lines'), 
    legend.position = 'top', # 'top','bottom','right','left'
    legend.title=element_blank(),
    text = element_text(size = 20), 
    axis.line = element_line(color = "black"),
    axis.title = element_text(face="bold",size = 20), 
    axis.text.x=element_text(face="bold",size = 18,angle=0,vjust = 0.5,colour = d),
    axis.text.y=element_text(size = 12),
    panel.border = element_blank(),
    panel.background = element_blank(),
    panel.grid.major =element_blank(),
    panel.grid.minor = element_blank()) + 
  stat_compare_means(label = "p.signif", method = "wilcox.test", 
                     size = 8, hide.ns = T, label.y = (max(box$exp)*1)) 
dev.off()


## ROC

# rocobj <- roc(group ~ ., data = roc_data, direction = "<")
rocobj <- roc(group ~ ., data = roc_data)
rocobj_legend <- c()
for (l in 1:length(rocobj)) {
  auc <- auc(rocobj[[l]])
  legend <- paste0(colnames(roc_data)[l+1],"_AUC: ",round(auc,3))
  rocobj_legend <- c(rocobj_legend,legend)
}
rocobj_legend

pdf(file = paste0("13_hub_ROC_", GSE_accession, ".pdf"), height = 7, width = 7, onefile = FALSE)
ggroc(rocobj,size = 1.1,legacy.axes=T) + 
  labs(x = "False positiverate", y = "True positiverate", title = GSE_accession)+
  geom_segment(aes(x = 0, xend = 1, y = 0, yend = 1), color="grey", linetype="dashed",size = 1)+
  theme(legend.title=element_blank(),
        legend.position = c(0.7,0.25),
        legend.text = element_text(size = 18, margin = margin (b = 12, unit = "pt")),
        text = element_text(size = 20),
        axis.line = element_line(colour = "black"),
        axis.ticks = element_line(colour = "black"),
        axis.title = element_text(size = 20, hjust = 0.5, colour = "black"),
        axis.text = element_text(size = 20, color = "black"),
        panel.background = element_rect(fill = NA),
        panel.border = element_rect(fill = NA, size = 1.5))+
  scale_color_discrete(breaks = colnames(roc_data)[-1],labels = rocobj_legend)
dev.off()

setwd("..")
