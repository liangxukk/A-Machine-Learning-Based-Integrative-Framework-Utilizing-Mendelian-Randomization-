
## Enrichment
pacman::p_load(clusterProfiler, org.Hs.eg.db, org.Mm.eg.db, treemap, GOplot, tidyverse, ggraph, ccgraph, tidygraph, 
               ggsci, scales, ggpubr) 

# 3. Enrichment -----------------------------------------------------------

file_name <- "03_Enrichment"; dir.create(file_name); setwd(file_name)

## 3.1 Intersecting genes-----------------------------

DEG <- readLines("../02_DEG/03_DEGs.txt")
MR <- readLines("../01_MR/06_MR_gene.txt")
gene_enrich <- Reduce(intersect, list(DEG, MR))
write.table(gene_enrich, file = "00_gene_enrich.txt",row.names = F, col.names = F, quote=F)

upset_list <- list(DEGs = DEG, 
                   MR_Gene = MR)
pdf(file = "00_Targets_venn.pdf",height=4,width=5,onefile=FALSE)
ggvenn::ggvenn(upset_list, 
       stroke_linetype = 2, 
       stroke_size = 1,
       text_size = 4,
       text_color = "black",
       # set_name_color = "red", 
       set_name_size = 4,
       fill_color = c("#91D0BE", "gold", "#6D9EC1")
)
dev.off()

## 3.2 GO-KEGG ----------------------------------------------------------------

gene = gene_enrich
pAdjustMethod <- "none"  ## BH none
source("D:/00_Laborer/00_1741/01_Database/00_code/GO_KEGG/GO_KEGG-v2.R")
enrich(gene)

setwd("..")
