## Mendelian Randomization

# remotes::install_github("MRCIEU/TwoSampleMR")
# remotes::install_github("MRCIEU/ieugwasr")
# remotes::install_github("MRCIEU/MRInstruments")
# remotes::install_github("Bioconductor/VariantAnnotation")
# remotes::install_github("Bioconductor/Rhtslib")
# remotes::install_github("Bioconductor/Rsamtools")
# remotes::install_github("Bioconductor/ensemblVEP")
# install.packages("../VariantAnnotation_1.52.0.tar.gz", repos = NULL)


pacman::p_load(TwoSampleMR, MRInstruments, doParallel, ggplot2, data.table, gwasglue2, dplyr, gassocplot2, coloc, ieugwasr, stringr)
rm(list = ls())

# MR -------------------------------------------------------------------

file_name = "01_MR_new"; dir.create(file_name); setwd(file_name)

exposure_file <- fread("../00_Rawdata/MBG.allHits.p1e4.txt") %>% as.data.frame()
exposure_file$exposure <- str_split(exposure_file$bac, pattern = fixed(".id.")) %>% sapply(.,"[",1)
exposure_file$id <- str_split(exposure_file$bac, pattern = fixed(".id.")) %>% sapply(.,"[",2)
write.table(exposure_file, "../00_Rawdata/MBG.allHits.clean.p1e4.txt", row.names = F, sep = "\t")

exposure_file <- "../00_Rawdata/MBG.allHits.clean.p1e4.txt"

# 读取肠道微生物和前列腺癌的GWAS数据
exposure_dat <- read_exposure_data(
  filename = exposure_file,
  sep = "\t",
  phenotype_col = "exposure",
  snp_col = "rsID",
  beta_col = "beta",
  se_col = "SE",
  effect_allele_col = "eff.allele",
  other_allele_col = "ref.allele",
  eaf_col = NULL,
  pval_col = "P.weightedSumZ",
  id_col = "id", 
  chr_col = "chr",
  pos_col = "pos"
)

# exposure_dat <- exposure_dat[exposure_dat$pval.exposure < 5e-8, ]
write.csv(exposure_dat, file = "01_exposure_data_5e-8.csv")


usethis::edit_r_environ()
## 添加成功后，保存，重启R--

ieugwasr::get_opengwas_jwt()

api_status()
user()


# gwas_id <- "ieu-b-85"
gwas_id <- "ebi-a-GCST90018905"

# SNP 列表
snps <- exposure_dat$SNP %>% unique()

# 设置每批的 SNP 数量
batch_size <- 1000  # 每批 1000 个 SNP

# 初始化一个空列表，用于存储每批的结果
outcome_data_list <- list()

# 分批下载数据
for (i in seq(1, length(snps), by = batch_size)) {
  start_index <- i
  end_index <- min(i + batch_size - 1, length(snps))
  snp_batch <- snps[start_index:end_index]
  
  cat("Processing batch", ceiling(i / batch_size), "of", ceiling(length(snps) / batch_size), "...\n")
  
  outcome_batch <- tryCatch({
    associations(
      variants = snp_batch,
      id = "ebi-a-GCST90018905"  # 替换为你的结局变量数据集 ID
    )
  }, error = function(e) {
    cat("Error in batch", ceiling(i / batch_size), ":", e$message, "\n")
    return(NULL)
  })
  
  if (!is.null(outcome_batch)) {
    outcome_data_list[[length(outcome_data_list) + 1]] <- outcome_batch
  }
  
  Sys.sleep(1)  # 每次请求后暂停 1 秒
}

# 合并所有批次的结果
outcome_dat <- do.call(rbind, outcome_data_list)

# 检查合并后的数据
cat("Total SNPs extracted:", nrow(outcome_dat), "\n")
print(head(outcome_dat))

# 转换为 TwoSampleMR 格式
outcome_dat <- format_data(
  outcome_dat,
  type = "outcome",  # 指定为结局数据
  phenotype_col = "trait",
  snp_col = "rsid",   # SNP 列名
  beta_col = "beta", # 效应值列名
  se_col = "se",     # 标准误列名
  effect_allele_col = "ea",  # 效应等位基因列名
  other_allele_col = "nea",    # 非效应等位基因列名
  eaf_col = "eaf",   # 效应等位基因频率列名
  pval_col = "p",  # P 值列名
  id_col = "id",
  chr_col = "chr",
  pos_col = "position"
)

write.csv(outcome_dat, file = "01_outcome_data.csv")
outcome_dat <- read.csv("01_outcome_data.csv", row.names = 1)
outcome_dat <- outcome_dat[outcome_dat$pval.outcome > 5e-8, ]


exposure_dat_list <- split(exposure_dat,list(exposure_dat$id.exposure))

for (i in names(exposure_dat_list)) {
  
  exposure_dat_list[[i]] <- subset(exposure_dat_list[[i]], pval.exposure < 1e-5)
  
  exposure_dat_list[[i]] <- clump_data(
    exposure_dat_list[[i]],
    clump_kb = 10000,  # LD 窗口大小（默认 250 kb）
    clump_r2 = 0.001, # LD r^2 阈值（默认 0.01）
    clump_p1 = 1e-5, # p 值阈值（默认 5e-8）
    pop = "EUR"      # 参考人群（如 "EUR" 欧洲人群）
  )
}

har_loop <- function(exposure_dat=exposure_dat_list){
  BBB=TwoSampleMR::harmonise_data(
    exposure_dat = exposure_dat, outcome_dat = outcome_dat)
  return(BBB)
}

detectCores(logical = FALSE)
cl<- makeCluster(6)

registerDoParallel(cl)
clusterEvalQ(cl,library(TwoSampleMR))
clusterExport(cl = cl, varlist = c("exposure_dat_list", "outcome_dat", "har_loop"))
start1 = Sys.time()
dat_list = parLapply(cl = cl, X = exposure_dat_list, fun = har_loop)
end1=Sys.time();end1-start1
stopCluster(cl)
dat <- do.call(rbind,dat_list)
dat <- subset(dat,mr_keep)

dat <- split(dat,list(dat$id.exposure))
length(dat)
names(dat) <- paste0("A", 1:length(dat))
deleteSNP = names(dat)[sapply(dat, nrow) < 3]
length(deleteSNP)

for (deleteSNPid in deleteSNP) {
  dat[[deleteSNPid]] <- NULL
}
length(dat)
dat2 <- do.call(rbind, dat)
length(unique(dat2$id.exposure))

##

res_hete <- mr_heterogeneity(dat2)
res_pleio <- mr_pleiotropy_test(dat2)
write.csv(res_hete, "02_Heterogeneity.csv", row.names = F)
write.csv(res_pleio, "02_Horizontal_pleiotropy.csv", row.names = F)

res=mr(dat2, method_list = c("mr_egger_regression",
                             "mr_weighted_median",
                             "mr_ivw_mre",
                             "mr_ivw_fe"))

################ result extract

# res$pval=round(res$pval,3)
res_hete <- res_hete[res_hete$method == "Inverse variance weighted", ]
colnames(res_hete)[8] <- "Q_pval_IVW"
colnames(res_pleio)[7] <- "hor_p_val"
res <- merge(res, res_hete[,c(1,8)], by = "id.exposure")
res <- merge(res, res_pleio[,c(1,7)], by = "id.exposure")

# res$`Gene stable ID` <- gsub("eqtl-a-", "", res$id.exposure)
# sym_ann <- fread("D:/00_1741/01_Database/UCSC/Ensembl_Gene_info.txt")[,c(1,3)]
# res <- merge(res, sym_ann, by = "Gene stable ID")

# res$id <- res$id.exposure
# prot_ann <- read.csv("D:/00_1741/01_Database/MR/prot-id.csv")
# res <- merge(res, prot_ann, by = "id")
write.csv(res, "03_result_all.csv", row.names = F)

############ output

res_sig2 <- data.frame(matrix(nrow = 0, ncol = 11))
colnames(res_sig2) <- colnames(res)
data <- res %>% subset(pval < 0.05
                       & hor_p_val > 0.05)
eqtl <- data$id.exposure %>% unique()
for (i in eqtl) {
  data <- res[res$id.exposure == i,]
  if (data$Q_pval_IVW[1] > 0.05) {
    res_sig2 <- rbind(res_sig2, data[data$method == "Inverse variance weighted (fixed effects)", ])
  }else{
    res_sig2 <- rbind(res_sig2, data[data$method == "Inverse variance weighted (multiplicative random effects)", ])
  }
}
res_sig2 <- res_sig2[res_sig2$pval < 0.05, ]
write.csv(res_sig2, "03_result_sig_mre+fe.csv", row.names = F)

#SNP转基因-------

library(biomaRt)
# BiocManager::install("ensemblVEP")
# BiocManager::install("VariantAnnotation")

data_snp <- dat2[dat2$id.exposure %in% res_sig2$id.exposure, ]
write.csv(data_snp, "04_result_sig_snp_information.csv", row.names = F)

# 定义SNP的rsid
rsid <- data_snp$SNP %>% unique()

# 使用Ensembl的人类数据集
ensembl_snp <- useEnsembl(biomart = "snps", dataset = "hsapiens_snp")
ensembl <- useEnsembl(biomart = "ensembl", dataset = "hsapiens_gene_ensembl")

listAttributes(ensembl_snp)
listFilters(ensembl_snp)

snp_info <- getBM(attributes = c('refsnp_id', 'ensembl_gene_stable_id', "chr_name", "chrom_start", "chrom_end"),
                  filters = 'snp_filter',
                  values = rsid,
                  mart = ensembl_snp)

snp_info <- snp_info[snp_info$ensembl_gene_stable_id != "",]

# 使用getBM函数查询基因名称
snp_info2 <- getBM(attributes = c('ensembl_gene_id', 'external_gene_name'),
                  filters = 'ensembl_gene_id',
                  values = snp_info$ensembl_gene_stable_id,
                  mart = ensembl)

snp_info <- merge(snp_info, snp_info2, by.x = "ensembl_gene_stable_id", by.y = "ensembl_gene_id")
snp_info <- snp_info[,c(2:5,1,6)]
write.csv(snp_info, "05_snp_to_gene.csv")


# MR-Forward-plot-------------------------------------------------

dir.create("MR_plot")
setwd("MR_plot")

outcomeid <- "ebi-a-GCST90018905"
outcome <- outcome_dat
sigid <- res_sig2$id.exposure %>% unique()
exp_data <- do.call(rbind, exposure_dat_list)
exp_data <- exp_data[exp_data$id.exposure %in% sigid, ]
exp_data$samplesize.exposure <- 18340


for (i in sigid) {
  
  exposureid <- i
  filename <- exp_data$exposure[exp_data$id.exposure == exposureid][1]
  dir.create(filename)
  setwd(filename)
  
  #提取暴露BMI的工具变量，SNP100个左右
  exposure_dat <- exp_data[exp_data$id.exposure == exposureid,]
  # exposure_dat <- extract_instruments(outcomes = exposureid,
  #                                     p1 = 5e-08,
  #                                     clump = TRUE, 
  #                                     r2 = 0.001,
  #                                     kb = 10000, 
  #                                     access_token = NULL)
  # exposure_dat$r2 <- (2 * (exposure_dat$beta.exposure^2) * exposure_dat$eaf.exposure * (1 - exposure_dat$eaf.exposure)) /
  #   (2 * (exposure_dat$beta.exposure^2) * exposure_dat$eaf.exposure * (1 - exposure_dat$eaf.exposure) +
  #      2 * exposure_dat$samplesize.exposure * exposure_dat$eaf.exposure * (1 - exposure_dat$eaf.exposure) * exposure_dat$se.exposure^2)
  # 
  # exposure_dat$F <- exposure_dat$r2 * (exposure_dat$samplesize.exposure - 2) / (1 - exposure_dat$r2)
  write.csv(exposure_dat,file="01.exposure_dat_input.csv",row.names = F,quote = F)
  
  #提取工具变量在结局中的信息（获得与暴露因素一致的SNP位点，会有重复值）
  
  # outcome <- read.csv("../../02_MR/01_outcome.csv", row.names = 1)
  outcome_dat <- outcome[outcome$SNP %in% exposure_dat$SNP,]
  # outcome_dat <- extract_outcome_data(snps = exposure_dat$SNP,
  # outcomes = outcomeid)
  write.csv(outcome_dat,file="02.outcome_dat_input.csv",row.names = F,quote = F)
  
  #调整SNP方向为一致
  dat <- harmonise_data(
    exposure_dat=exposure_dat,
    outcome_dat=outcome_dat)
  
  dat1 <- dat[!duplicated(dat$SNP),] 
  # dat1 <- dat[-4,]
  # dat1 <- dat1[dat1$SNP != "rs887829",]
  write.csv(dat1,file="03.Harmonize_effects.csv",row.names = F,quote = F)
  
  ## steiger检验
  
  # dat2 <- harmonise_data(exposure_dat, outcome_dat)
  # out <- directionality_test(dat2)
  # out
  # write.csv(out, "03_steigerout.csv")

  res=mr(dat1, method_list = c("mr_egger_regression","mr_weighted_median",
                               "mr_ivw_fe","mr_simple_mode","mr_weighted_mode"))
  write.csv(res,file="04.MR_results.csv",row.names = F,quote = F)
  
  #换算成OR值(是非型结局要换算，连续型不换算)
  OR <-generate_odds_ratios(res)
  write.csv(OR,file="04.MR_results_OR.csv",row.names = F,quote = F)
  
  #异质性检验 P>0.05
  df_MR_hetero <- mr_heterogeneity(dat1)
  write.csv(df_MR_hetero,file="05.MR_heterogeneity.csv",row.names = F,quote = F)
  
  #水平效应检验 P>0.05 #最重要
  pleio <- mr_pleiotropy_test(dat1)
  write.csv(pleio,file="06.Horizontal_pleiotropy.csv",row.names = F,quote = F)
  
  #留一法(逐个剔除检验)
  single <- mr_leaveoneout(dat1, method = mr_ivw_fe)
  single[,1:2] <- single[,3:4]
  source("D:/00_Laborer/00_1741/01_Database/00_code/MR/mr_leaveoneout_plot_m.R")
  p1 <- mr_leaveoneout_plot_m(single)
  pdf(file="07.leave_one_out.pdf",width=7,height=5,onefile=FALSE)
  # mr_leaveoneout_plot(single)
  print(p1)
  dev.off()
  
  #散点图
  res$method[3] <- "IVW"
  dat1$outcome <- dat1$id.outcome
  dat1$exposure <- dat1$id.exposure
  source("D:/00_Laborer/00_1741/01_Database/00_code/MR/mr_scatter_plot_m.R")
  p2 <- mr_scatter_plot_m(res,dat1)
  pdf(file="08.Scatter.pdf",width=9.5,height=8,onefile=FALSE)
  # mr_scatter_plot(res,dat1)
  print(p2)
  dev.off()
  
  #Forest Plot
  # res_single <- mr_singlesnp(dat1, all_method = c("mr_ivw_mre", "mr_egger_regression"))
  # res_single[res_single=="All - Inverse variance weighted (multiplicative random effects)"] <- "All - IVW"
  res_single <- mr_singlesnp(dat1, all_method = c("mr_ivw_fe", "mr_egger_regression"))
  res_single[res_single=="All - Inverse variance weighted (fixed effects)"] <- "All - IVW"
  write.csv(res_single,file="09.singlesnp_res.csv",row.names = F,quote = F)
  source("D:/00_Laborer/00_1741/01_Database/00_code/MR/mr_forest_plot_m.R")
  p3 <- mr_forest_plot_m(res_single)
  pdf(file="10.Forest_Plot.pdf",width=7,height=5,onefile=FALSE)
  #mr_forest_plot(res_single)
  print(p3)
  dev.off()
  
  #漏斗图
  source("D:/00_Laborer/00_1741/01_Database/00_code/MR/mr_funnel_plot_m.R")
  p4 <- mr_funnel_plot_m(res_single)
  pdf(file="11.Funnel.pdf",width=6,height=5,onefile=FALSE)
  #mr_funnel_plot(res_single)
  print(p4)
  dev.off()

  setwd("..")
  
}

setwd("..")


