
rm(list = ls())
gc()
options(stringsAsFactors = F) 

# .libPaths(c("/home/data/t130525/anaconda3/envs/r-4.2.0/lib/R/library/",.libPaths()))

library(scales)
library(ggplot2)
library(cowplot)
library(dplyr)
library(data.table)
library(stringr)
library(Matrix)
library(Seurat)
library(harmony)
# library(kableExtra)
library(ggpubr)
# library(clustree)
# library(scRNAstat) 

# search()

# 1.1 import --------------------------------------------------------------

wd <- "../GSE193337_RAW/"
project_name <- list.files(wd)
raw_data_dir <- paste0(wd, project_name)

creat_seurat_object <- function(raw_data_dir,project_name){
  raw_data <- Read10X(raw_data_dir)
  dat_object <- CreateSeuratObject(counts = raw_data, project = project_name, min.cells = 3, min.features = 200)
  cat(paste0(raw_data_dir,': Number of genes: ',dim(dat_object)[1]),file = 'number_log.log',append = T,sep = '\n')
  cat(paste0(raw_data_dir,': Number of cells: ',dim(dat_object)[2]),file = 'number_log.log',append = T,sep = '\n')
  return(dat_object)
}

rawdata <- list()
for (i in 1:length(raw_data_dir)) {
  rawdata[[project_name[i]]] <- creat_seurat_object(raw_data_dir[i],project_name[i])
}

scRNA <- merge(x = rawdata[[1]], y = rawdata[-1], project = "GSE193337")

# 1.2 QC_VlnPlot---------------

scRNA[["percent.mt"]] <- PercentageFeatureSet(scRNA, pattern = "^MT-")
QC_pic <- VlnPlot(scRNA, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3, raster=FALSE, group.by = 'orig.ident',pt.size = 0)
dir.create("01_QC")
pdf('01_QC/01_QC_VlnPlot_before.pdf',height = 8, width = 20)
print(QC_pic)
dev.off()

### QC

scRNA <- subset(scRNA, subset = nCount_RNA <= 50000 & nFeature_RNA <= 6000 & percent.mt <= 20)
# 24375 features across 23781 samples within 1 assay  
QC_pic <- VlnPlot(scRNA, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3, raster=FALSE, group.by = 'orig.ident',pt.size = 0)
pdf('01_QC/02_QC_VlnPlot_after.pdf',height = 8, width = 20)
print(QC_pic)
dev.off()

# 标准化和特征选择
# scRNA0 <- scRNA
scRNA <- NormalizeData(scRNA) %>% FindVariableFeatures(nfeatures = 2000) %>% ScaleData()

### high_varible_genes

dir.create("02_high_varible_genes")
name = as.character(scRNA@project.name)

hvg_info <- HVFInfo(scRNA)
hvg_info <- hvg_info[order(hvg_info$variance.standardized, decreasing = TRUE), ]
top10 <- rownames(hvg_info)[1:10]

# top10 <- head(VariableFeatures(scRNA), 10)
plot6 <- VariableFeaturePlot(scRNA, pt.size = 2, cols = c("black", "blue"))
plot7 <- LabelPoints(plot = plot6, points = top10, repel = T)+ NoLegend()
pdf(paste0('02_high_varible_genes/',name," visualize high varible genes.pdf"),width=7,height =7)
# p <- CombinePlots(plots = list(plot6, plot7), legend = "bottom")
print(plot7)
dev.off()

# 1.3 Harmony------------------------------------------------------------------

### PCA
scRNA <- RunPCA(scRNA, npcs=50, verbose=FALSE)

# Integrated with harmony
scRNA_harmony <- IntegrateLayers(object = scRNA,
                                 method = HarmonyIntegration, # 需要什么方法改变这里即可
                                 orig.reduction = 'pca', # 这里降维必须选择pca
                                 new.reduction = 'harmony') # 储存在新的降维结果integrated.cca中
scRNA_harmony[['RNA']] <- JoinLayers(scRNA_harmony[['RNA']])

dir.create("03_PCA")
pdf(file = "03_PCA/01_PCA_sample.pdf",width = 7, height = 6)
print(DimPlot(scRNA_harmony, dims = 1:2, reduction = "pca",group.by = 'orig.ident') )
dev.off()

pdf(file = "03_PCA/02_Examine and visualize PCA singlecells with ElbowPlot.pdf", width = 9, height = 9)
print(ElbowPlot(scRNA_harmony, ndims = 50, reduction = "pca"))
dev.off()

# 1.4 降维聚类-----

Idents(scRNA_harmony)
pc.num = 1:30
scRNA_harmony <- RunUMAP(scRNA_harmony, reduction = "harmony", dims = pc.num)
# scRNA_harmony <- RunTSNE(scRNA_harmony, reduction = "harmony", dims = pc.num)
scRNA_harmony <- FindNeighbors(scRNA_harmony, reduction = "harmony", dims = pc.num)
scRNA_harmony <- FindClusters(scRNA_harmony, resolution = 0.1)
save(scRNA_harmony, file = "01_scRNA_harmony_no_annotion.rda")

my36colors <-c( '#E5D2DD', '#53A85F', '#F1BB72', '#F3B1A0', '#D6E7A3', '#57C3F3','#476D87', '#E95C59', '#E59CC4', 
                '#AB3282', '#23452F', '#BD956A','#8C549C', '#585658', '#9FA3A8', '#E0D4CA', '#5F3D69', '#C5DEBA', 
                '#58A4C3', '#E4C755', '#F7F398','#AA9A59', '#E63863', '#E39A35','#C1E6F3', '#6778AE', '#91D0BE', 
                '#B53E2B', '#712820', '#DCC1DD','#CCE0F5', '#CCC9E6', '#625D9E', '#68A180', '#3A6963', '#968175')

# ## 添加分组
sample_case <- c("GSM5793828","GSM5793829","GSM5793831","GSM5793832")
scRNA_harmony@meta.data$group <- ifelse(scRNA_harmony@meta.data$orig.ident %in% sample_case, "Case", "Control")

plot_umap_sample <- DimPlot(scRNA_harmony, reduction = "umap", group.by = "orig.ident",pt.size = 1)+ggtitle('')
plot_umap_group <- DimPlot(scRNA_harmony, reduction = "umap", group.by = "group",pt.size = 1)+ggtitle('')
plot_umap_cluster <- DimPlot(scRNA_harmony, reduction = "umap", label = TRUE, repel = TRUE,pt.size = 1,cols = my36colors,
                             label.size = 6)
# plot_sample_cluster <- plot_umap_sample+plot_umap_cluster
pdf(file = "03_PCA/03_umap_cluster.pdf", width = 10, height = 9)
print(plot_umap_sample)
print(plot_umap_group)
print(plot_umap_cluster)
dev.off()

# plot_tsne_sample <- DimPlot(scRNA, reduction = "tsne", group.by = "orig.ident",pt.size = 1)+ggtitle('')
# plot_tsne_cluster <- DimPlot(scRNA, reduction = "tsne", label = TRUE, repel = TRUE,pt.size = 1,cols = my36colors,
#                              label.size = 6)
# plot_sample_cluster <- plot_tsne_sample+plot_tsne_cluster
# pdf(file = "03_PCA/tsne_sample_cluster.pdf", width = 10, height = 9)
# print(plot_tsne_sample)
# print(plot_tsne_cluster)
# dev.off()


# # 1.5 FindAllMarkers-------------
# 
# dir.create("04_Findmarker")
# all.markers <- FindAllMarkers(scRNA_harmony, only.pos = F, min.pct = 0.25, logfc.threshold = 0.25)
# all.markers <- all.markers[order(all.markers$cluster,all.markers$avg_log2FC,decreasing = T),]
# write.csv(all.markers, "04_Findmarker/01_marker_genes.csv")
# # all.markers1 <- FindAllMarkers(scRNA, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25,test.use = 'roc')
# # all.markers1 <- all.markers1[order(all.markers1$cluster,all.markers1$avg_diff,decreasing = T),]
# # write.csv(all.markers1, "各簇marker genes roc.csv")
# 
# # all.markers %>% group_by(cluster) %>% top_n(n = 9, wt = avg_log2FC) %>%
# #   kable("html",caption = '<center>**表10. 各簇marker genes top9**</center>') %>%
# #   kable_styling(bootstrap_options = "striped", full_width = F)%>%
# #   scroll_box(width = "1000px", height = "500px")
# 
# write.csv(all.markers %>% group_by(cluster) %>% top_n(n = 9, wt = avg_log2FC),file='04_Findmarker/02_marker_genes_top9.csv')
# # write.csv(all.markers1 %>% group_by(cluster) %>% top_n(n = 9, wt = avg_diff),file='各簇marker genes top9 roc.csv')

# 1.6 annotion----------------

dir.create("05_annotion")

features <- c("CD3E", "CD3D",
              "CDH5", "PECAM1", "VWF",
              "KRT18", "EPCAM",
              "LYZ", "CD68",
              "COL1A1", "FGF7",
              "CD79A", "CD19", "CD79B", 
              "TPSAB1", "KIT", "CPA3"
)

DotPlot(scRNA_harmony, features = features, group.by = 'seurat_clusters',assay='RNA') +
  theme_bw()+
  theme(panel.grid = element_blank(), 
        axis.text.x=element_text(hjust = 1,vjust=1,size = 15,angle = 45),
        axis.text.y=element_text(hjust = 1,vjust=0.5,size = 15),
  )+
  labs(x=NULL,y=NULL)+guides(size=guide_legend(order=3))+
  scale_color_gradientn(values = seq(0,1,0.2),colours = c('#330066','#336699','#66CC66','#FFCC33'))

clustername <- c("T cells",
                 "Endothelial cells",
                 "Epithelial cells",
                 "Monocytes and macrophages",
                 "Epithelial cells",
                 "Epithelial cells",
                 "Epithelial cells",
                 "Fibroblasts",
                 "B cells",
                 "Mast cells",
                 "Fibroblasts", 
                 "Endothelial cells"
)

# Idents(scRNA) <- scRNA@meta.data$integrated_snn_res.0.1
new.cluster.ids <- clustername
names(new.cluster.ids) <- levels(scRNA_harmony)
# Idents(scRNA) <- scRNA$seurat_clusters
scRNA_harmony <- RenameIdents(scRNA_harmony, new.cluster.ids)
scRNA_harmony$cell <- Idents(scRNA_harmony)

# scRNA$cell <- factor(scRNA$cell, levels = c("B_lymphocytes",
#                                             "Endothelial_cells",
#                                             "Fibroblasts",
#                                             "Macrophages_and_Monocytes",
#                                             "Mast_cells",
#                                             "Plasmocyte",
#                                             "Mesenchymal",
#                                             "Smooth_muscle_cell",
#                                             "T_lymphocytes"
# ))


pdf(file = "05_annotion/01_DotPlot.pdf", width = 13, height = 6)

DotPlot(scRNA_harmony, features = features, group.by = 'seurat_clusters',assay='RNA') +
  theme_bw()+
  theme(panel.grid = element_blank(), 
        axis.text.x=element_text(hjust = 1,vjust=1,size = 15,angle = 45),
        axis.text.y=element_text(hjust = 1,vjust=0.5,size = 15),
  )+
  labs(x=NULL,y=NULL)+guides(size=guide_legend(order=3))+
  scale_color_gradientn(values = seq(0,1,0.2),colours = c('#330066','#336699','#66CC66','#FFCC33'))

DotPlot(scRNA_harmony, features = features, group.by = 'cell',assay='RNA') +
  theme_bw()+
  theme(panel.grid = element_blank(), 
        axis.text.x=element_text(hjust = 1,vjust=1,size = 15,angle = 45),
        axis.text.y=element_text(hjust = 1,vjust=0.5,size = 15),
  )+
  labs(x=NULL,y=NULL)+guides(size=guide_legend(order=3))+
  scale_color_gradientn(values = seq(0,1,0.2),colours = c('#330066','#336699','#66CC66','#FFCC33'))

dev.off()

pdf(file = "05_annotion/02_umap_cluster_cell.pdf", width = 11, height = 9)
DimPlot(scRNA_harmony, reduction = "umap", label = TRUE, repel = F,pt.size = 1,cols = my36colors, label.size = 6)
dev.off()

save(scRNA_harmony, file='02_scRNA_harmony_annotion.rda')



# 1.6 细胞异质性 ---------------------------------------------------------------

dir.create("05_Heterogeneity")

a <- table(scRNA_harmony$orig.ident,scRNA_harmony@active.ident)
write.csv(a, "05_Heterogeneity/01_各类细胞数量.csv")

a <- round(a/rowSums(a),4)
Cellratio <- as.data.frame(a)
write.csv(a, "05_Heterogeneity/02_各类细胞比例.csv")
# Cellratio$group <- ifelse(Cellratio$Var1 %in% c('LZ002','LZ004 ','LZ010','LZ012','LZ017','LZ018','LZ019'),'NOA','NORMAL')

colnames(Cellratio)[1:2] <- c("Sample", "cell")
# Cellratio$Sample <- factor(Cellratio$Sample, levels = c("IP-1","IP-1N", "IP3", "IP-4", "IP-6", "IP-7"))
p <- 
  ggboxplot(Cellratio, x = "cell", y = "Freq",
            color = "Sample", ylab = "cell ratio",
            xlab = "", add = "jitter", size = 1, axis.line = 2, palette=my36colors) +
  # scale_fill_brewer(palette="Set1") +
  # scale_fill_manual(values = my36colors) +
  geom_vline(xintercept = seq(from = 1.5, to = 17.5, by = 1), lty = 4, col = "#E39A35", lwd = 1) +
  # stat_compare_means(label = "p.signif", label.y = max(Cellratio[, 3]), aes(group = Var1),method = 'kruskal.test') + 
  rotate_x_text(45)

pdf(file = "05_Heterogeneity/03_各类群细胞含量比率统计.pdf", width = 12, height = 6)
print(p)
dev.off()
# Cellratio$group <- factor(Cellratio$group,levels = unique(Cellratio$group),ordered = T)
# Cellratio <- Cellratio[order(Cellratio$group),]
# Cellratio$Var1 <- factor(Cellratio$Var1,levels = unique(Cellratio$Var1),ordered = T)
p1 <- ggplot(data = Cellratio,aes(x=Sample,y=Freq,fill=cell))+
  geom_bar(stat="identity",position = "fill")+
  ##添加辅助线
  geom_hline(yintercept=0.25,linetype=2,size=1)+
  geom_hline(yintercept=0.50,linetype=2,size=1)+
  geom_hline(yintercept=0.75,linetype=2,size=1)+
  ##旋转坐标轴
  # coord_flip()+
  xlab("")+
  # scale_fill_brewer(value = my36colors)+
  scale_fill_manual(values = my36colors)+
  theme_classic()+
  theme(
    ##设置图例上方，字体，大小，颜色
    legend.position = "top",legend.title = element_blank(),
    legend.text=element_text(size = 14,colour = "black"),
    ####设置边框线粗细，颜色，类型
    line = element_line(colour = "black", size = 1, linetype = 1), 
    ###设置坐标轴标题字体，颜色，大小
    axis.title=element_text(size = 16,face="bold",colour = "black"),
    ###设置坐标轴标签字体，颜色，大小
    axis.text.y = element_text(size = 14,colour = "black"),
    axis.text.x = element_text(size = 12,colour = "black"))

pdf(file = "05_Heterogeneity/04_各类群细胞含量堆积图.pdf", width = 12, height = 6)
print(p1)
dev.off()


# 1.7 hub gene----------------

scRNA_harmony@meta.data$cell_group <- paste0(scRNA_harmony@meta.data$cell, " - ", scRNA_harmony@meta.data$group)
features <- c("BNC2", "MRAP2", "PLEKHA2")

dir.create("06_hub_gene")

pdf('06_hub_gene/01_hub-DotPlot-cell.pdf',height = 5, width = 8)
DotPlot(scRNA_harmony, features = features, group.by = "cell", assay='RNA') + RotatedAxis()
dev.off()

pdf('06_hub_gene/02_hub-DotPlot-group.pdf',height = 3, width = 6)
DotPlot(scRNA_harmony, features = features, group.by = "group", assay='RNA') + RotatedAxis()
dev.off()

pdf('06_hub_gene/03_hub-DotPlot-cell_dis.pdf',height = 8, width = 8)
DotPlot(scRNA_harmony, features = features, group.by = "cell_group", assay='RNA') + RotatedAxis()
dev.off()

# pdf('06_hub_gene/04_hub-VlnPlot-cell.pdf',height = 12, width = 18)
# VlnPlot(scRNA, features = features, group.by = "cell", assay='RNA', ncol = 3, raster=FALSE)
# dev.off()
# 
# pdf('06_hub_gene/hub-VlnPlot-cell_dis.pdf',height = 12, width = 21)
# VlnPlot(scRNA, features = features, group.by = "cell_group", assay='RNA', ncol = 3, raster=FALSE)
# dev.off()

DefaultAssay(scRNA) <- "RNA"

pdf('06_hub_gene/04_hub-FeaturePlot-cell.pdf',height = 6, width = 19)
FeaturePlot(scRNA_harmony, features = features, ncol = 3, pt.size = 0.1, raster=FALSE) 
# scale_colour_gradientn(colours = c('#330066','#336699','#66CC66','#FFCC33'))
dev.off()


# 1.8 cell-phone--------

library(CellChat)
library(NMF)
library(ggalluvial)
library(patchwork)
library(ggplot2)
library(svglite)
options(stringsAsFactors = FALSE)


dir.create("07_cellphone")

# 创建cellchat对象

scRNA_harmony[["RNA4"]] <- as(object = scRNA_harmony[["RNA"]], Class = "Assay")
DefaultAssay(scRNA_harmony) <- "RNA4"

table(scRNA_harmony@meta.data$group)

# 按分组拆分对象
cellchat_group <- SplitObject(scRNA_harmony, split.by = 'group')

# 循环处理每个分组
for (i in names(cellchat_group)) {
  # 获取当前分组的对象
  object <- cellchat_group[[i]]
  
  # 创建 CellChat 对象
  cellchat <- createCellChat(object@assays$RNA4@data)
  
  # 添加元数据
  meta <- data.frame(cellType = object$cell, row.names = Cells(object))
  cellchat <- addMeta(cellchat, meta = meta, meta.name = "cell")
  cellchat <- setIdent(cellchat, ident.use = "cell") # set "labels" as default cell identity
  groupSize <- as.numeric(table(cellchat@idents)) # number of cells in each cell group
  
  # 加载与设定需要的 CellChatDB 数据库
  CellChatDB <- CellChatDB.human
  CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling") # use Secreted signaling for cell-cell communication analysis
  cellchat@DB <- CellChatDB.use # set the used database in the object
  
  # 预处理表达数据以进行细胞间相互作用分析
  cellchat <- subsetData(cellchat) # subset the expression data of signaling genes for saving computation cost
  cellchat <- identifyOverExpressedGenes(cellchat) 
  cellchat <- identifyOverExpressedInteractions(cellchat)
  cellchat <- projectData(cellchat, PPI.human)
  
  # 根据表达值推测细胞互作的概率（cellphonedb 是用平均表达值代表互作强度）。
  cellchat <- computeCommunProb(cellchat, raw.use = FALSE, population.size = TRUE) #如果不想用上一步 PPI 矫正的结果，raw.use = TRUE 即可。
  # Filter out the cell-cell communication if there are only few number of cells in certain cell groups
  cellchat <- filterCommunication(cellchat, min.cells = 10)
  df.net <- subsetCommunication(cellchat)
  write.csv(df.net, paste0("07_cellphone/", i, "_net_lr.csv"))
  
  cellchat <- computeCommunProbPathway(cellchat)
  df.netp <- subsetCommunication(cellchat, slot.name = "netP")
  write.csv(df.netp, paste0("07_cellphone/", i, "_net_pathway.csv"))
  
  # 统计细胞和细胞之间通信的数量（有多少个配体 - 受体对）和强度（概率）
  cellchat <- aggregateNet(cellchat)
  # 计算每种细胞各有多少个
  groupSize <- as.numeric(table(cellchat@idents))
  
  # 定义一个非常小的非零值
  epsilon <- 1e-6
  
  # 将值为 0 的数据替换为 epsilon
  cellchat@net$count[cellchat@net$count == 0] <- epsilon
  cellchat@net$weight[cellchat@net$weight == 0] <- epsilon
  
  # 绘图
  # par(mfrow = c(1, 2), xpd = TRUE)
  p1 <- netVisual_circle(cellchat@net$count, vertex.weight = groupSize, weight.scale = T, 
                         label.edge = F, title.name = "Number of interactions")
  p2 <- netVisual_circle(cellchat@net$weight, vertex.weight = groupSize, weight.scale = T, 
                         label.edge = F, title.name = "Interaction weights/strength")
  p3 <- plot_grid(p1, p2, ncol = 2)
  pdf(paste0("07_cellphone/", i, "_cellphone.pdf"), width = 14, height = 7)
  print(p3)
  # ggsave(paste0("07_cellphone/", i, "_cellphone.pdf"), width = 14, height = 7)
  dev.off()
  
  print(i)
}





















# 1.7 hub box---------------------------------------------------------------------

mymatrix <- as.data.frame(scRNA_harmony@assays$RNA4@data)
mymatrix2<-t(mymatrix)%>%as.data.frame()
mymatrix2[,1]<-scRNA_harmony$cell
mymatrix3 <- data.frame(cell = scRNA_harmony$cell,
                        group = scRNA_harmony$group,
                        mymatrix2[,features])

pic <- list()

for (i in 3:4) {
  box <- mymatrix3[,c(1:2,i)]
  colnames(box)[3] <- "exp"
  pic[[colnames(mymatrix3)[i]]] <- 
    ggplot(box,aes( x = cell, y = exp, fill = group)) + 
    geom_boxplot(alpha=0.7) + 
    scale_fill_manual(values=c("#53A85F","#E95C59"))+ 
    #scale_x_discrete()+
    labs(x="",y="Expression level", title = colnames(mymatrix3)[i])+
    theme_bw() + 
    theme(#plot.margin=unit(rep(3,4),'lines'), 
      legend.position = 'top',
      legend.title=element_blank(),
      text = element_text(size = 20), 
      axis.line = element_line(color = "black"),
      axis.title = element_text(face="bold",size = 22), 
      axis.text.x=element_text(face="bold",size = 18,vjust = 1, hjust = 1, angle = 45),
      axis.text.y=element_text(size = 12),
      panel.border = element_blank(),
      panel.background = element_blank(),
      panel.grid.major =element_blank(),
      panel.grid.minor = element_blank()) + 
    stat_compare_means(label = "p.signif", method = "t.test", size = 10,
                       hide.ns = T, label.y = (max(box[,3])*0.95)) 
}

pdf(paste0('06_hub_gene/05.hub.box.pdf'),height = 7,width = 10)
print(pic)
dev.off()


# 1.8 time ---------------------------------------------------------------------

library(irlba)
library(monocle)

devtools::load_all("/home/data/t130525/00_Project/doudou/r.doudou/monocle")

rm(list = ls())
gc()

load("02_scRNA_ann.rda")
dir.create(("08_time"))

## 样本拆分

object_time <- scRNA_harmony[,which(Idents(scRNA_harmony) %in% c("Spermatocytes", "Spermatids", "Spermatogonia"))]
object_time <- scRNA_harmony
object_time[["RNA4"]] <- as(object = object_time[["RNA"]], Class = "Assay")
DefaultAssay(object_time) <- "RNA4"

object_time@meta.data$cellname <- object_time@assays$RNA4@data@Dimnames[[2]]
sample <- object_time@meta.data$cellname 
sample <- unique(sample)

set.seed(888)
index <- caTools::sample.split(sample, SplitRatio = 0.5)
object_time <- object_time[,index]

table(object_time$cell)
# Ex Inhib 
# 13523  4351 
rm(sample_all)
gc()

##提取表型信息--细胞信息(建议载入细胞的聚类或者细胞类型鉴定信息、实验条件等信息)
expr_matrix <- as(as.matrix(object_time@assays$RNA4@counts), 'sparseMatrix')
##提取表型信息--细胞信息(建议载入细胞的聚类或者细胞类型鉴定信息、实验条件等信息)
p_data <- object_time@meta.data
#p_data$celltype <- object_time@active.ident ##整合每个细胞的细胞鉴定信息到p_data里面。如果已经添加则不必重复添加
##提取基因信息 如生物类型、gc含量等
f_data <- data.frame(gene_short_name = row.names(object_time@assays$RNA4),row.names = row.names(object_time@assays$RNA4))
##expr_matrix的行数与f_data的行数相同(gene number), expr_matrix的列数与p_data的行数相同(cell number)

pd <- new('AnnotatedDataFrame', data = p_data)

fd <- new('AnnotatedDataFrame', data = f_data)

cds <- newCellDataSet(expr_matrix, phenoData = pd,featureData = fd,lowerDetectionLimit = 0.5,expressionFamily = negbinomial.size())

cds <- estimateSizeFactors(cds)
cds <- estimateDispersions(cds)

cds <- detectGenes(cds, min_expr = 0.1) #过滤基因，将会在fData(cds)中添加一列num_cells_expressed
# expressed_genes <- row.names(subset(fData(cds),num_cells_expressed >= 10)) #过滤掉在小于10个细胞中表达的基因

#使用2000高边基因
# DefaultAssay(object_time) <- "integrated"
express_genes <- VariableFeatures(object_time)
cds<- setOrderingFilter(cds, express_genes)
plot_ordering_genes(cds)

#降维
cds <- reduceDimension(cds,max_components = 2,method = 'DDRTree')
saveRDS(cds,"03_object_time_monocle2.rds")
# cds <- readRDS("object_time_monocle2.rds")

#拟时序轴轨迹构建并排列
cds <- orderCells(cds) ### long times
# saveRDS(cds,"object_time_monocle2.rds")

# cds <- readRDS("object_time_monocle2.rds")
#按照细胞状态
pdf(file = "08_time/01.cell_object_time_time.pdf", width = 5, height = 5)
plot_cell_trajectory(cds,color_by="Pseudotime", size=1,show_backbone=TRUE)+ scale_colour_gradient(low = "#4DBBD5FF", high = "#DC0000FF")
dev.off()

pdf(file = "08_time/02.cell_object_time_State.pdf", width = 5, height = 5)
plot_cell_trajectory(cds, color_by = "State", cell_size =0.7,show_backbone=TRUE)
dev.off()

pdf(file = "08_time/03.cell_object_time_cell.pdf", width = 7, height = 5)
plot_cell_trajectory(cds, color_by = "cell", cell_size =0.7,show_backbone=TRUE)
dev.off()

pdf(file = "08_time/04.cell_object_time_Group.pdf", width = 5, height = 5)
plot_cell_trajectory(cds, color_by = "group", cell_size =0.7)+
  scale_colour_manual(values = c("#91D1C2FF","#FF7F00")
                      #"Control" = "#91D1C2FF","IgAN" = "#FF7F00"
  )   #,cols =c("Control"="#91D1C2FF","IgAN"="#FF7F00")
dev.off()

hub <- features
cds_subset <- cds[hub,]
##可视化：以state/celltype/pseudotime进行
p1 <- plot_genes_in_pseudotime(cds_subset, color_by = "State")
p2 <- plot_genes_in_pseudotime(cds_subset, color_by = "cell")
p3 <- plot_genes_in_pseudotime(cds_subset, color_by = "Pseudotime")
plotc <- p1|p2|p3
ggsave("08_time/05.Genes_pseudotimeplot.pdf", plot = p3, width = 8, height = 8)
ggsave("08_time/05.Genes_Stateplot.pdf", plot = p1, width = 8, height = 8)



# 1.9 monocle3 ------------------------------------------------------------

rm(list = ls())
gc()
options(stringsAsFactors = F) 

library(scales)
library(ggplot2)
library(cowplot)
library(dplyr)
library(data.table)
library(stringr)
library(Matrix)
library(Seurat)
library(harmony)
library(monocle3)

dir.create("08_time")

load("02_scRNA_harmony_annotion.rda")
DefaultAssay(scRNA_harmony) <- "RNA"
expression_matrix <- GetAssayData(scRNA_harmony, assay = 'RNA',layer  = 'counts')
cell_metadata <- scRNA_harmony@meta.data 
gene_annotation <- data.frame(gene_short_name = rownames(expression_matrix))
rownames(gene_annotation) <- rownames(expression_matrix)
cds <- new_cell_data_set(expression_matrix,
                         cell_metadata = cell_metadata,
                         gene_metadata = gene_annotation)

# cds@clusters$UMAP$clusters <- Idents(scRNA_harmony)

# 归一化/预处理数据
cds <- preprocess_cds(cds, method = "PCA", num_dim = 30)

# 这个函数用于确认设定的dim数是否足够代表主要变异
# plot_pc_variance_explained(cds)

# 降维聚类，可选择UMAP、PCA或者TSNE
cds <- reduce_dimension(cds,reduction_method='UMAP',
                        preprocess_method = 'PCA')
cds <- cluster_cells(cds) #cluster your cells

# 轨迹推断
cds <- learn_graph(cds)

save(cds, file='03_scRNA_harmony_time.rda')

pdf(file = "08_time/monocle3_hub.pdf", width = 15, height = 5)
plot_cells(cds,
           genes=features,
           label_cell_groups=FALSE,
           show_trajectory_graph=FALSE)
dev.off()



pdf(file = "08_time/monocle3_plot1.pdf", width = 7, height = 7)
plot_cells(cds, 
           color_cells_by = 'cell',
           label_groups_by_cluster=FALSE,
           cell_size=0.5,
           group_label_size=4,
           trajectory_graph_color='#023858',
           label_leaves = F,
           label_branch_points = F)
plot_cells(cds,
           color_cells_by = 'cell',
           label_groups_by_cluster=FALSE,
           cell_size=0.5,
           group_label_size=4,
           trajectory_graph_color='#023858',
           trajectory_graph_segment_size = 1)
# plot_cells(cds, 
#            color_cells_by = 'partition',
#            label_groups_by_cluster=FALSE,
#            cell_size=1,group_label_size=4,
#            trajectory_graph_color='#023858',
#            trajectory_graph_segment_size = 1)
dev.off()



cds0 <- cds
cds <- cds0

cds <- order_cells(cds) 

# 可视化
pdf(file = "08_time/monocle3_plot2.pdf", width = 8.5, height = 7)
plot_cells(cds, 
           label_cell_groups = F, 
           color_cells_by = "pseudotime", 
           label_branch_points = F, 
           graph_label_size = 0, 
           cell_size=0.5, 
           trajectory_graph_color='black',
           trajectory_graph_segment_size = 1)
dev.off()



# 1.8 time ---------------------------------------------------------------------

library(monocle)

rm(list = ls())
gc()

load("02_scRNA_harmony_ann.rda")
dir.create(("08_time"))

## 样本拆分

object_time <- scRNA_harmony[,which(Idents(scRNA_harmony) %in% c("T_lymphocytes"))]
object_time[["RNA4"]] <- as(object = object_time[["RNA"]], Class = "Assay")
DefaultAssay(object_time) <- "RNA4"

object_time@meta.data$cellname <- object_time@assays$RNA4@data@Dimnames[[2]]
sample <- object_time@meta.data$cellname 
sample <- unique(sample)

# set.seed(438)
# index <- caTools::sample.split(sample, SplitRatio = 0.3)
# object_time <- object_time[,index]

table(object_time$cell)
# Ex Inhib 
# 13523  4351 
rm(sample_all)
gc()

##提取表型信息--细胞信息(建议载入细胞的聚类或者细胞类型鉴定信息、实验条件等信息)
expr_matrix <- as(as.matrix(object_time@assays$RNA4@counts), 'sparseMatrix')
##提取表型信息--细胞信息(建议载入细胞的聚类或者细胞类型鉴定信息、实验条件等信息)
p_data <- object_time@meta.data
#p_data$celltype <- object_time@active.ident ##整合每个细胞的细胞鉴定信息到p_data里面。如果已经添加则不必重复添加
##提取基因信息 如生物类型、gc含量等
f_data <- data.frame(gene_short_name = row.names(object_time@assays$RNA4),row.names = row.names(object_time@assays$RNA4))
##expr_matrix的行数与f_data的行数相同(gene number), expr_matrix的列数与p_data的行数相同(cell number)

pd <- new('AnnotatedDataFrame', data = p_data)

fd <- new('AnnotatedDataFrame', data = f_data)

cds <- newCellDataSet(expr_matrix, phenoData = pd,featureData = fd,lowerDetectionLimit = 0.5,expressionFamily = negbinomial.size())

cds <- estimateSizeFactors(cds)
cds <- estimateDispersions(cds)

cds <- detectGenes(cds, min_expr = 0.1) #过滤基因，将会在fData(cds)中添加一列num_cells_expressed
# expressed_genes <- row.names(subset(fData(cds),num_cells_expressed >= 10)) #过滤掉在小于10个细胞中表达的基因

#使用2000高边基因
# DefaultAssay(object_time) <- "integrated"
express_genes <- VariableFeatures(object_time)
cds<- setOrderingFilter(cds, express_genes)
plot_ordering_genes(cds)

#降维
cds <- reduceDimension(cds,max_components = 2,method = 'DDRTree')
# saveRDS(cds,"object_time_monocle2.rds")
# cds <- readRDS("object_time_monocle2.rds")

#拟时序轴轨迹构建并排列
cds <- orderCells(cds) ### long times
# saveRDS(cds,"object_time_monocle2.rds")

# cds <- readRDS("object_time_monocle2.rds")
#按照细胞状态
pdf(file = "08_time/01.cell_object_time_time.pdf", width = 7, height = 4.5)
plot_cell_trajectory(cds,color_by="Pseudotime", size=1,show_backbone=TRUE)+ scale_colour_gradient(low = "#4DBBD5FF", high = "#DC0000FF")
dev.off()

pdf(file = "08_time/02.cell_object_time_State.pdf", width = 7, height = 4.5)
plot_cell_trajectory(cds, color_by = "State", cell_size =0.7,show_backbone=TRUE)
dev.off()

pdf(file = "08_time/03.cell_object_time_cell.pdf", width = 7, height = 4.5)
plot_cell_trajectory(cds, color_by = "cell", cell_size =0.7,show_backbone=TRUE)
dev.off()

pdf(file = "08_time/04.cell_object_time_Group.pdf", width = 7, height = 4.5)
plot_cell_trajectory(cds, color_by = "group", cell_size =0.7)+
  scale_colour_manual(values = c("#91D1C2FF","#FF7F00")
                      #"Control" = "#91D1C2FF","IgAN" = "#FF7F00"
  )   #,cols =c("Control"="#91D1C2FF","IgAN"="#FF7F00")
dev.off()

hub <- features
cds_subset <- cds[hub,]
##可视化：以state/celltype/pseudotime进行
p1 <- plot_genes_in_pseudotime(cds_subset, color_by = "State")
p2 <- plot_genes_in_pseudotime(cds_subset, color_by = "cell")
p3 <- plot_genes_in_pseudotime(cds_subset, color_by = "Pseudotime")
plotc <- p1|p2|p3
ggsave("08_time/05.Genes_pseudotimeplot.pdf", plot = p3, width = 8, height = 8)
ggsave("08_time/05.Genes_Stateplot.pdf", plot = p1, width = 8, height = 8)



