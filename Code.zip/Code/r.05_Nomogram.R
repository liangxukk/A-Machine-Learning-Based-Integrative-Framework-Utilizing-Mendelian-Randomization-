# 6. Nomogram ------------------------------------------------------------------

file_name <- "05_Nomogram"
dir.create(file_name)
setwd(file_name)

library(rms)

group <- group_xl
exp <- read.csv("../02_DEG/00_expression_normalized.csv", row.names = 1, check.names = F)
exp <- log2(exp + 1)
# exp <- exp_xl_fpkm

exp_logic <- data.frame(group = group$group, t(exp[hub,]))
exp_logic$group <- ifelse(exp_logic$group == "Control", 0, 1)

range(exp_logic[,-1])

f_lrm <-lrm(group ~ ., data=exp_logic, x=TRUE, y=TRUE, maxit=1000)

ddist <- datadist(exp_logic)
options(datadist='ddist')

nomogram <- nomogram(f_lrm,fun=function(x)1/(1+exp(-x)), 
                     fun.at = c(0.01,0.5,0.99),
                     funlabel = "Probability of Case", 
                     lp=F,  
                     conf.int = F, 
                     abbrev = F
)

pdf(file="01_nomogram.pdf" ,width=10,height=7)
plot(nomogram, lplabel = "Linear Predictor", xfrac = 0.25, varname.label = TRUE, varname.label.sep = "=",
     ia.space = 0.2, tck = NA, tcl = -0.2, lmgp = 0.3, points.label = "Points", total.points.label = "Total Points",
     total.sep.page = FALSE, cap.labels = FALSE, cex.var = 1.6, cex.axis = 1.05, lwd = 5,
     label.every = 1, col.grid = gray(c(0.8, 0.95)))

dev.off()

prob <-  predict(f_lrm, exp_logic[, -1])
pred_LR <- data.frame(prob, group = exp_logic$group, stringsAsFactors = F)

pdf(file="02_roc.pdf" ,width=6,height=6) 
LR.roc <- plot.roc(pred_LR$group,pred_LR$prob,ylim=c(0,1),xlim=c(1,0),
                   smooth=F, #绘制平滑曲线
                   ci=TRUE,
                   main="",
                   lwd=2, #线的粗细
                   legacy.axes=T,
                   print.auc = T)
dev.off()

# colnames(exp_logic)
# rocobj <- roc(group ~ ., data = exp_logic)
# glmfit <- glm(data = exp_logic, group ~ BNC2+MRAP2+WTAP)
# 
# rocobj[["Nomogram"]] <- roc(exp_logic$group, fitted(glmfit))
# rocobj_legend <- c()
# for (l in 1:length(rocobj)) {
#   auc <- auc(rocobj[[l]])
#   legend <- paste0(names(rocobj)[l],"_AUC: ",round(auc,2))
#   rocobj_legend <- c(rocobj_legend,legend)
# }
# rocobj_legend
# 
# GSE_accession <- "GSE40888"
# pdf(file = paste0("03_Nomogram_ROC_", GSE_accession, ".pdf"), height = 7, width = 7, onefile = FALSE)
# ggroc(rocobj,size = 1.1,legacy.axes=T) + 
#   labs(x = "False positiverate", y = "True positiverate", title = "")+
#   geom_segment(aes(x = 0, xend = 1, y = 0, yend = 1), color="grey", linetype="dashed",size = 1)+
#   theme(legend.title=element_blank(),
#         legend.position = c(0.7,0.25),
#         legend.text = element_text(size = 18, margin = margin (b = 12, unit = "pt")),
#         text = element_text(size = 20),
#         axis.line = element_line(colour = "black"),
#         axis.ticks = element_line(colour = "black"),
#         axis.title = element_text(size = 20, hjust = 0.5, colour = "black"),
#         axis.text = element_text(size = 20, color = "black"),
#         panel.background = element_rect(fill = NA),
#         panel.border = element_rect(fill = NA, size = 1.5))+
#   scale_color_discrete(breaks = names(rocobj),labels = rocobj_legend)
# dev.off()


##  校准曲线

exp_logic <- data.frame(group = group$group, t(exp[hub,]))
f_lrm <-lrm(group ~ ., data=exp_logic, x=TRUE, y=TRUE, maxit=1000)

set.seed(438)
cal <- calibrate(f_lrm)
pdf(file="03_calibrate.pdf",width=6,height=6)
plot(cal)
dev.off()

##  DCA

# install.packages("rmda")
library(rmda)
# install_github("mdbrown/DecisionCurve")
exp_logic$group <- ifelse(exp_logic$group == "Control", 0, 1)

hub

Nomogram <- decision_curve(group ~ BNC2 + MRAP2 + PLEKHA2,data = exp_logic
                           #,policy = "opt-in"
                           ,study.design = 'cohort')
BNC2 <- decision_curve(group ~ BNC2, data = exp_logic
                        #,policy = "opt-in"
                        ,study.design = 'cohort')
MRAP2 <- decision_curve(group ~ MRAP2, data = exp_logic
                         #,policy = "opt-in"
                         ,study.design = 'cohort')
PLEKHA2 <- decision_curve(group ~ PLEKHA2, data = exp_logic
                        #,policy = "opt-in"
                        ,study.design = 'cohort')
list <- list(Nomogram, BNC2, MRAP2, PLEKHA2)

pdf("04_DCA_.pdf",width=5,height=5)
par(mgp = c(2.5, 1, 0), mar = c(4, 4.5, 1, 1))
plot_decision_curve(list,
                    curve.names= c("Nomogram", "BNC2", "MRAP2", "PLEKHA2"),
                    cost.benefit.axis =FALSE,
                    col= brewer.pal(6, "Set1"),
                    confidence.intervals=FALSE,
                    standardize = FALSE,
                    legend.position="bottomleft")
dev.off()

setwd("..")
